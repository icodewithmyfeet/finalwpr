'use strict';

const xhr = new XMLHttpRequest();

const login = document.getElementById('login')
const logout = document.getElementById('logout')
const auth = document.getElementById('auth')
const notauth = document.getElementById('not-auth')
const getCookie = (name) => {
    var nameEQ = name + "="
    var ca = document.cookie.split(';')
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i]
        while (c.charAt(0) == ' ') c = c.substring(1, c.length)
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length)
    }
    return null
}

if (getCookie('user_name')) {
    login.style.display = 'none'
    logout.style.display = 'block'
    notauth.style.display = 'none'
    auth.style.display = 'block'
}
else {
    auth.style.display = 'none'
    notauth.style.display = 'block'
    login.style.display = 'block'
    logout.style.display = 'none'
}

const my_courses = document.getElementById('my-courses')

function loadMyCourse() {
    xhr.onload = () => {
        const courses = JSON.parse(xhr.responseText)
        courses.forEach(c => {
            const li = document.createElement('li')
            li.classList.add('flex', 'py-6')
            const div1 = document.createElement('div')
            div1.classList.add('h-24', 'w-24', 'flex-shrink-0', 'overflow-hidden', 'rounded-md', 'border', 'border-gray-200')
            const img = document.createElement('img')
            img.classList.add('h-full', 'w-full', 'object-cover', 'object-center')
            img.src = 'https://www.freeiconspng.com/thumbs/courses-icon/courses-icon-8.png'
            img.alt = 'My Courses'


            const div2 = document.createElement('div')
            div2.classList.add('ml-4', 'flex', 'flex-1', 'flex-col')
            const div3 = document.createElement('div')

            const div4 = document.createElement('div')

            div4.classList.add('flex', 'justify-between', 'text-base', 'font-medium', 'text-gray-900')

            const h3 = document.createElement('h3')


            const a = document.createElement('a')
            a.innerHTML = c.infor


            const p2 = document.createElement('p')
            p2.classList.add('mt-1', 'text-sm', 'text-gray-500')
            p2.innerHTML = c.course


            const div5 = document.createElement('div')
            div5.classList.add('flex', 'flex-1', 'items-end', 'justify-between', 'text-sm')
            const div6 = document.createElement('div')
            div6.classList.add('flex')

            const btn_ = document.createElement('button')
            btn_.type = 'button'
            btn_.classList.add('font-medium', 'text-indigo-600', 'hover:text-indigo-500')
            btn_.style.color = '#c60d23'
            btn_.innerHTML = 'Leave Course'



            const btn = document.createElement('button')
            btn.type = 'button'
            btn.classList.add('font-medium', 'text-indigo-600', 'hover:text-indigo-500')
            btn.innerHTML = 'Go to Course'

            btn.onclick = (e) => {
                window.location.href = '/course/' + c.id + '/quizes'
            }

            div6.appendChild(btn_)
            div5.appendChild(div6)

            btn_.onclick = (e) => {
                let user_id = getCookie('user_id')
                let course_id = c.id
                let xhr_ = new XMLHttpRequest();
                xhr_.onload = () => {
                    const alert = JSON.parse(xhr_.responseText)
                    if (alert == 'Unenrolled') {
                        btn.style.display = 'none'
                        btn_.innerHTML = alert
                        btn_.style.color = '#889688'
                        btn_.disabled = true
                    }
                };
                xhr_.open('POST', 'http://localhost:8000/api/unenroll')
                xhr_.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
                xhr_.send('user_id=' + user_id + '&course_id=' + course_id)
            }
            h3.appendChild(a)
            div4.appendChild(h3)
            div4.appendChild(btn)
            div3.appendChild(div4)
            div3.appendChild(p2)
            div2.appendChild(div3)
            div2.appendChild(div5)
            div1.appendChild(img)

            li.appendChild(div1)
            li.appendChild(div2)
            my_courses.appendChild(li)
        });
    };
    xhr.open('GET', 'http://localhost:8000/api/my/courses')
    xhr.send()
}

window.addEventListener("load", loadMyCourse)

function Logout() {
    xhr.onload = () => {
        const alert = JSON.parse(xhr.responseText)
        if (alert == 'Logout') {
            window.location.href = '/'
        }
    };
    xhr.open('POST', 'http://localhost:8000/api/logout')
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    xhr.send()
}

logout.onclick = Logout

