'use strict';

const xhr = new XMLHttpRequest();

const login_form = document.getElementById('login-form')
const btn_login = document.getElementById('btn-login')
const alert_login = document.getElementById('alert-login')
alert_login.style.color = 'red';
function Login() {
    let user_name = login_form['user-name'].value
    let password = login_form['password'].value

    if (user_name.length < 4) return alert_login.innerHTML = 'User name must be greater than 4'

    if (password.length < 4) return alert_login.innerHTML = 'Password must be greater than 4'

    xhr.onload = () => {
        const alert = JSON.parse(xhr.responseText)
        if (alert == 'Logined') {
            let s = 3;
            let t = setInterval(function () {
                if (s == 0) {
                    document.getElementById('cd').textContent = 'Redirecting...'
                    clearInterval(t);
                    setTimeout(() => {
                        window.location.href = '/my/courses'
                    }, 2000);
                } else {
                    document.getElementById('cd').textContent = s
                    s--;
                }
            }, 1000);
        }
        else {
            alert_login.innerHTML = alert
        }

    };
    xhr.open('POST', 'http://localhost:8000/api/login')
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    xhr.send("user_name=" + user_name + "&password=" + password)
}

btn_login.onclick = Login
