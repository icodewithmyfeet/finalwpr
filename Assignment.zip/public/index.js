'use strict';

const xhr = new XMLHttpRequest();
const announcements = document.getElementById('announcements');
const login = document.getElementById('login')
const logout = document.getElementById('logout')

const both_lg_rg = document.getElementById('both-btn')
const getCookie = (name) => {
    var nameEQ = name + "="
    var ca = document.cookie.split(';')
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i]
        while (c.charAt(0) == ' ') c = c.substring(1, c.length)
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length)
    }
    return null
}

if (getCookie('user_name')) {
    both_lg_rg.style.display = 'none'
    login.style.display = 'none'
    logout.style.display = 'block'
}
else {
    both_lg_rg.style.display = 'flex'
    login.style.display = 'block'
    logout.style.display = 'none'
}

function loadData() {
    console.log('aa')
    xhr.onload = () => {
        const announ_data = JSON.parse(xhr.responseText)
        announ_data.forEach(a => {
            const div1 = document.createElement('div')
            div1.classList.add('relative', 'flex', 'flex-col', 'gap-6', 'sm:flex-row', 'md:flex-col', 'lg:flex-row')
            const div2 = document.createElement('div')
            div2.classList.add('flex', 'h-12', 'w-12', 'items-center', 'justify-center', 'rounded-xl', 'bg-indigo-500', 'text-white', 'sm:shrink-0')
            const div3 = document.createElement('div')
            div3.classList.add('sm:min-w-0', 'sm:flex-1')

            const p1 = document.createElement('p')
            p1.classList.add('text-lg', 'font-semibold', 'leading-8', 'text-gray-900')
            p1.innerHTML = a.header
            const p2 = document.createElement('p')
            p2.classList.add('mt-2', 'text-base', 'leading-7', 'text-gray-600')
            p2.innerHTML = a.body
            div3.appendChild(p1)
            div3.appendChild(p2)

            div1.appendChild(div2)
            div1.appendChild(div3)
            announcements.appendChild(div1)
        });
    };
    xhr.open('GET', 'http://localhost:8000/api/annoucements')
    xhr.send()
}

window.addEventListener("load", loadData)

function Logout() {
    xhr.onload = () => {
        const alert = JSON.parse(xhr.responseText)
        if (alert == 'Logout') {
            window.location.href = '/'
        }
    };
    xhr.open('POST', 'http://localhost:8000/api/logout')
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    xhr.send()
}

logout.onclick = Logout

