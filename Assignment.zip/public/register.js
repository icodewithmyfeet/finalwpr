'use strict';

const xhr = new XMLHttpRequest();

const register_form = document.getElementById('register-form')
const btn_register = document.getElementById('btn-register')
const alert_register = document.getElementById('alert-register')
document.getElementById('alert-register').style.color = 'red';

function Register () {
    let user_name = register_form['user_name'].value
    let password = register_form['password'].value
    let re_password = register_form['re_password'].value

    if (user_name.length < 4) return alert_register.innerHTML = 'User name must be greater than 4'

    if (password.length < 4) return alert_register.innerHTML = 'Password must be greater than 4'

    if (re_password != password) return alert_register.innerHTML = 'Re-enter password does not match'

    xhr.onload = () => {
        const alert = JSON.parse(xhr.responseText)
        
        if(alert == 'Compeleted!') document.getElementById('alert-register').style.color = 'green';
        alert_register.innerHTML = alert
    };
    xhr.open('POST', 'http://localhost:8000/api/register')
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    xhr.send("user_name=" + user_name + "&password=" + password)
}

btn_register.onclick = Register
