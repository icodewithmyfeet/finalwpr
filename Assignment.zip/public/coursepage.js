'use strict';

const xhr = new XMLHttpRequest();

const login = document.getElementById('login')
const logout = document.getElementById('logout')
const auth = document.getElementById('auth')
const notauth = document.getElementById('not-auth')
const getCookie = (name) => {
    var nameEQ = name + "="
    var ca = document.cookie.split(';')
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i]
        while (c.charAt(0) == ' ') c = c.substring(1, c.length)
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length)
    }
    return null
}

if (getCookie('user_name')) {
    login.style.display = 'none'
    logout.style.display = 'block'
    notauth.style.display = 'none'
    auth.style.display = 'block'
}
else {
    auth.style.display = 'none'
    notauth.style.display = 'block'
    login.style.display = 'block'
    logout.style.display = 'none'
}



function loadQuiz() {
    const list_quiz = document.getElementById('quizes')
    const course_id = getCookie('course_id')
    xhr.onload = () => {
        const quizes = JSON.parse(xhr.responseText)
        quizes.forEach(q => {
            const li = document.createElement('li')
            li.classList.add('flex', 'items-center', 'justify-between', 'py-3', 'pl-3', 'pr-4', 'text-sm')
            const div = document.createElement('div')
            div.classList.add('flex', 'w-0', 'flex-1', 'items-center')

            const span = document.createElement('span')
            span.classList.add('ml-2', 'w-0', 'flex-1', 'truncate')
            span.innerHTML = q.title
            const div_ = document.createElement('div')
            div_.classList.add('ml-4', 'flex-shrink-0')
            const a = document.createElement('a')
            a.classList.add('font-medium', 'text-indigo-600', 'hover:text-indigo-500')
            a.innerHTML = 'Start quiz'
            a.href = '#'

            a.onclick = (e) => {
                window.location.href = '/course/' + course_id + '/doquiz/' + q.id
            }

            div.appendChild(span)
            div_.appendChild(a)
            li.appendChild(div)
            li.appendChild(div_)


            list_quiz.appendChild(li)
        });
    };
    xhr.open('GET', '/api/course/' + course_id + '/quizes')
    xhr.send()
}

window.addEventListener("load", loadQuiz)

function Logout() {
    xhr.onload = () => {
        const alert = JSON.parse(xhr.responseText)
        if (alert == 'Logout') {
            window.location.href = '/'
        }
    };
    xhr.open('POST', 'http://localhost:8000/api/logout')
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    xhr.send()
}

logout.onclick = Logout

