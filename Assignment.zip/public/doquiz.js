'use strict';

const xhr = new XMLHttpRequest();

const login = document.getElementById('login')
const logout = document.getElementById('logout')
const auth = document.getElementById('auth')
const notauth = document.getElementById('not-auth')
const getCookie = (name) => {
    var nameEQ = name + "="
    var ca = document.cookie.split(';')
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i]
        while (c.charAt(0) == ' ') c = c.substring(1, c.length)
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length)
    }
    return null
}

if (getCookie('user_name')) {
    login.style.display = 'none'
    logout.style.display = 'block'
    notauth.style.display = 'none'
    auth.style.display = 'block'
}
else {
    auth.style.display = 'none'
    notauth.style.display = 'block'
    login.style.display = 'block'
    logout.style.display = 'none'
}


function loadQuestion() {
    const doquiz = document.getElementById('doquiz')
    const course_id = getCookie('course_id')
    const quiz_id = getCookie('quiz_id')

    xhr.onload = () => {
        let list_user_answer = [];
        const questions = JSON.parse(xhr.responseText)
        questions.forEach((q, index) => {
            const div = document.createElement('div');
            div.classList.add('p-3');
            const h3 = document.createElement('h3');
            h3.style.fontWeight = 700
            h3.style.color = '#445588'
            const span = document.createElement('span');
            span.style.wordBreak = 'break-all';
            h3.style.marginBottom = '10px'
            span.innerHTML = 'Question ' + (index + 1) + ': ' + q.question;
            const list_group = document.createElement('div');
            list_group.classList.add('mx-5');
            q.choices.split(',').forEach((choice, index) => {
                const list_group_item = document.createElement('li');

                const input = document.createElement('input');
                input.classList.add('mr-2')
                input.setAttribute('type', 'radio');
                input.setAttribute('value', index);
                input.setAttribute('name', 'q-' + q.id);
                input.setAttribute('id', 'q-' + q.id + '-' + index);
                input.onclick = ((e) => {
                    let answer_question = {
                        question_id: q.id,
                        user_answer: e.target.value
                    }
                    list_user_answer.push(answer_question);
                })
                const label = document.createElement('label');

                label.setAttribute('for', 'q-' + q.id + '-' + index);
                label.innerHTML = choice;

                list_group_item.appendChild(input);
                list_group_item.appendChild(label);
                list_group.appendChild(list_group_item);
            });

            h3.appendChild(span);
            div.appendChild(h3);
            div.appendChild(list_group);


            doquiz.appendChild(div);
        })
        const submit = document.getElementById('submit-quiz');
        let scores = 0;
        submit.onclick = (e) => {
            console.log('aa')
            const p = parseFloat(10 / (questions.length));
            list_user_answer.forEach(x => {
                questions.forEach(y => {
                    if (x.question_id == y.id) {
                        if (x.user_answer == y.correctAnswer) {
                            scores += p
                        }
                    }
                })
            })
            alert("<Score: " + scores.toFixed(2) + ">")
            submit.disabled = true
        }
        

    };
    xhr.open('POST', '/api/course/' + course_id + '/doquiz/' + quiz_id)
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    xhr.send('course_id=' + course_id + '&quiz_id=' + quiz_id)
}

window.addEventListener("load", loadQuestion)

function Logout() {
    xhr.onload = () => {
        const alert = JSON.parse(xhr.responseText)
        if (alert == 'Logout') {
            window.location.href = '/'
        }
    };
    xhr.open('POST', 'http://localhost:8000/api/logout')
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    xhr.send()
}

logout.onclick = Logout

