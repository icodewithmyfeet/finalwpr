"use strict";
const express = require('express');
const app = express();

const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({
    extended: false
}));

app.use(bodyParser.json())

var cookieParser = require('cookie-parser');

app.use(cookieParser());

const db = new sqlite3.Database('coursedb.db');
app.use(express.static('public'))
app.get('/', (req, res) => {
    res.sendFile('public/index.html', { root: __dirname })
});

app.get('/api/annoucements', (req, res) => {
    db.all(`select * from Announcement`, (err, announcements) => {
        if (!err) {
            res.json(announcements);
        }
        else {
            res.status(500)
            res.send(err)
        }
    })
});

app.get('/register', (req, res) => {
    res.sendFile('public/register.html', { root: __dirname })
});

app.post('/api/register', (req, res) => {
    db.run(`insert into User(user_name, password) values(?, ?)`, [req.body.user_name, req.body.password], (err) => {
        if (!err) {
            res.json('Compeleted!')
        }
        else {
            res.json('User name already exists, please change')
        }
    })
})
app.get('/login', (req, res) => {
    res.sendFile('public/login.html', { root: __dirname })
});

app.post('/api/login', (req, res) => {
    db.get(`select * from User where user_name = ?`, req.body.user_name, (err, user) => {
        if (user) {
            if (user.password != req.body.password) {
                res.json('Wrong password, please re-enter')
            }
            else {
                res.cookie('user_id', user.id);
                res.cookie('user_name', user.user_name);
                res.json('Logined')
            }
        }
        else {
            res.json('User name do not exists')
        }
    })
})

app.post('/api/logout', (req, res) => {
    res.clearCookie('user_id')
    res.clearCookie('user_name')
    res.clearCookie('course_id')
    res.json('Logout')
});

app.get('/my/courses', (req, res) => {
    res.sendFile('public/mycourse.html', { root: __dirname })
});
app.get('/all/courses', (req, res) => {
    res.sendFile('public/allcourse.html', { root: __dirname })
});

app.get('/course/:courseid/quizes', (req, res) => {
    res.cookie('course_id', req.params.courseid);
    res.sendFile('public/coursepage.html', { root: __dirname })
});

app.get('/course/:courseid/doquiz/:quizid', (req, res) => {
    res.cookie('quiz_id', req.params.quizid);
    res.sendFile('public/doquiz.html', { root: __dirname })
});

app.get('/api/all/courses', (req, res) => {
    db.all(`select Course.id, Course.course, Course.infor, Course.cost from Course
    where Course.id not in (select Owned_course.course_id from Owned_course where Owned_course.user_id = ?)`, req.cookies.user_id, (err, courses) => {
        if (!err) {
            res.json(courses)
        }
    })
});
app.get('/api/my/courses', (req, res) => {
    db.all(`select Course.id, Course.course, Course.infor, Course.cost from Course
    where Course.id in (select Owned_course.course_id from Owned_course where Owned_course.user_id = ?)`, req.cookies.user_id, (err, courses) => {
        if (!err) {
            res.json(courses)
        }
    })
});
app.post('/api/allcourse/enroll', (req, res) => {
    db.run(`insert into Owned_course(course_id, user_id) values(?, ?)`, [req.body.course_id, req.body.user_id], (err) => {
        if (!err) {
            res.json('Enrolled')
        }
    })
});
app.post('/api/unenroll', (req, res) => {
    db.run(`delete from Owned_course where course_id = ? and user_id = ?`, [req.body.course_id, req.body.user_id], (err) => {
        if (!err) {
            res.json('Unenrolled')
        }
    })
});

app.get('/api/course/:courseid/quizes', (req, res) => {
    db.all(`select * from Quiz where course_id = ?`, req.params.courseid, (err, quizes) => {
        if (!err) {
            res.json(quizes)
        }
    })
});
app.post('/api/course/:courseid/doquiz/:quizid', (req, res) => {
    db.all(`select * from Question where quiz_id = ?`, req.body.quiz_id, (err, questions) => {
        if (!err) {
            res.json(questions)
        }
    })
});

app.listen(8000)